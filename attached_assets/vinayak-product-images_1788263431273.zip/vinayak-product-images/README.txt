VINAYAK INTERNATIONAL — PRODUCT IMAGES
=======================================

Total: 191 product images, extracted from the official CARBON Brass catalog PDF.
Every image has a clean white background (ready for the website's image style).

FOLDER STRUCTURE
----------------
Images are organised into 9 category folders. Inside each folder, every file
is named by its product CODE (exactly as printed in the catalog).

  door-knockers/            15 images   (codes 2500-2514)
  brass-door-furniture/     15 images   (codes 2600-2614)
  casement-stay-fasteners/  13 images   (codes 3400-3410, 3411 A, 3411 B)
  cabinet-hardware/         65 images   (codes 3000-3061, 3600-3602)
  curtain-tie-back/         12 images   (codes 2800-2811)
  symbol-plaques/           13 images   (codes 3500-3512)
  coat-hooks/               23 images   (codes 2900-2922)
  alpha-numerals/            5 images   (codes 2700-2704)
  artware/                  30 images   (codes 2000-2029)

HOW TO USE ON THE WEBSITE (Replit)
----------------------------------
Upload this whole folder to Replit. Each image's file name IS the product code,
and the folder it sits in IS the product category. That is all the information
needed to place every product on the correct category page with the correct
code label shown underneath.

NOTES
-----
- "2506": the PDF had a small printing typo ("25016") on this one code.
  It has been corrected to 2506 here.
- "3035": this code does not exist in the catalog (the catalog itself skips
  from 3034 to 3036), so there is no 3035 image.
- alpha-numerals: brass letters (A-Z) and numerals (0-9) are sold as a set.
  The 5 images here are representative samples for the category, as shown in
  the catalog.
